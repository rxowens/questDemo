﻿using JsonApiDotNetCore.Models;
using System;
using System.Collections.Generic;

namespace BookReviewDemo
{
    public partial class Author : Identifiable
    {
        public Author()
        {
            Book = new HashSet<Book>();
        }

      //  [Attr("authorId")]
        public int AuthorId { get; set; }


      //  [Attr("firstName")]
        public string FirstName { get; set; }

     //   [Attr("lastName")]
        public string LastName { get; set; }

        public virtual ICollection<Book> Book { get; set; }
    }
}
