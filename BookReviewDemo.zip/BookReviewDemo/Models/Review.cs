﻿using System;
using System.Collections.Generic;

namespace BookReviewDemo
{
    public partial class Review
    {
        public int BookId { get; set; }
        public int ReviewerId { get; set; }
        public string ReviewerName { get; set; }
        public string Body { get; set; }

        public virtual Book Book { get; set; }
    }
}
