﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JsonApiDotNetCore.Models;

namespace questtest.Models
{
    public class Dish : Identifiable
    {
        [Attr("name")]
        public string Name { get; set; }

        [Attr("rating")]
        public int Rating { get; set; }


         [HasOne("restaurant")]
         public virtual Restaurant Restaurant { get; set; }
         public int RestaurantId { get; set; }
    }

}

