using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.EntityFrameworkCore;
using questtest.Models;
using JsonApiDotNetCore.Extensions;

namespace questtest
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc(option => option.EnableEndpointRouting = false);
     services.AddDbContext<AppDbContext>(opt =>
      {
           opt.UseInMemoryDatabase("Quest");
     });;

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        // public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
            public void Configure(IApplicationBuilder app, Microsoft.AspNetCore.Hosting.IWebHostEnvironment env, AppDbContext context)
        {
            if (env.IsDevelopment())
            {

                app.UseDeveloperExceptionPage();
                app.UseHttpsRedirection();
             
                app.UseJsonApi();
            }


            /// ron 
            context.Database.EnsureCreated();
              if (context.Restaurants.Any() == false)
                  {
                Restaurant sushiPlace = new Restaurant { Name = "Sushi Place" };
                Restaurant burgerPlace = new Restaurant { Name = "Burger Place" };
                context.Restaurants.Add(sushiPlace);
                context.Restaurants.Add(burgerPlace);
                context.SaveChanges();
                
                context.Dishes.Add(new Dish
                {
                    Restaurant = sushiPlace,
                    Name = "California Roll"
                      });
                
                context.Dishes.Add(new Dish
                {
                    Restaurant = sushiPlace,
                    Name = "Volcano Roll"
                      });
                
                context.Dishes.Add(new Dish
                {
                    Restaurant = burgerPlace,
                    Name = "Barbecue Burger",
                          });
               
               context.Dishes.Add(new Dish
                {
                    Restaurant = burgerPlace,
                    Name = "Slider"
                      });
              
                context.SaveChanges();
                  }
            /// 



            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapGet("/", async context =>
                {
                    await context.Response.WriteAsync("Hello World!");
                });
            });
        }
    }
}
