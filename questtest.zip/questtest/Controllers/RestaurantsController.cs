﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using JsonApiDotNetCore.Controllers;
using JsonApiDotNetCore.Services;
using Microsoft.Extensions.Logging;
using questtest.Models;

namespace questtest.Controllers
{
    public class RestaurantsController : JsonApiController<Restaurant>
    {
        public RestaurantsController(
            IJsonApiContext jsonApiContext,
            IResourceService<Restaurant> resourceService,
            ILoggerFactory loggerFactory)
            : base(jsonApiContext, resourceService, loggerFactory)
        { }
    }
}
